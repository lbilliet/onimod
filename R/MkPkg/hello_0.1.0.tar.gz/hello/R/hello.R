#'@title hello world
#'@name hello
#'@description A derivative from Hello world
#'@usage Print hello world
#'@param x a number
#'@return "x hello world"
#'@export


hello <- function(x) {
  print(paste(x, "Hello, world!"))
}

### step1: create an R package project (file -> new project -> package)
### step2: create your functions
### step3: document your functions with #'@
### step4: delete 'NAMESPACE.Rd' and 'hello.Rd' files
# ils ne seront pas modifies par roxygen sinon.
### step5: run roxygen2::roxygenize(), qui crée des fichiers Rd a partir des @commentaires
### step6: build le package (Build -> Clean and rebuild)
### step7: tu peux ensuite l'exporter en binary (pas de compatibilite entre
# systemes d'exploitation mais moins de place utilisee)
# ou en code source (compatible)


### un tuto qui a l'air pas mal et qui utilise document a la place de roxygen (ça a l'air de faire la meme chose)
# 'http://tinyheero.github.io/jekyll/update/2015/07/26/making-your-first-R-package.html'
